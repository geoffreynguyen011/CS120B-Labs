/*	Partner(s) Name & E-mail: Geoffrey Nguyen (gnguy011), Eric Pham (epham002)
 *	Lab Section: B21
 *	Assignment: Lab #1  Exercise #1
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */


#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
	DDRA = 0x00; PORTA = 0xFF;
	DDRB = 0xFF; PORTB = 0x00;
	
	unsigned char tmpA = 0x00;
	unsigned char tmpB = 0x00;
	unsigned char tmpC = 0x00;
    while (1) 
    {
		tmpA = PINA & 0x01;
		tmpC = PINA & 0x02;
		if (tmpA == 0x01 && tmpC != 0x02) {
			tmpB = (tmpB & 0xFC) | 0x01;
		}
		else {
			tmpB = (tmpB & 0xFC) | 0x00;
		}
		
	PORTB = tmpB;
	}
	return 0;
}

